/*
 * @author Federico Landini
 */
@SuppressWarnings("serial")
public class Exceptions extends Exception{

	Exceptions(String message){
		super(message);
	}
}